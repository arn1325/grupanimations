package com.example.minah.animations;

/**
 * Created by miNaH on 4/17/2018.
 */

class WELCOME_TIMEOUT {
}
